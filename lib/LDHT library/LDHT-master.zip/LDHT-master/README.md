# LDHT
LinkIt One DHT library (DHT11 can work!)
Written by Lin Wei Ting in National Taipei University of Technology Applied Network Laboratory. Taipei, Taiwan.
Example testing sketch for various DHT11, DHT21, DHT22 humidity/temperature sensors
